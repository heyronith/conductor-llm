# Task 6.2 Review Manifest: Full Validation, Token-Weighted Metrics, Real Cost Audit, and Continuation Proof

**Generated Date**: August 21, 2026  
**Modal Run IDs**: `run_1787329929` (Task 6A Pretraining), `ap-D9uRknTzD8w4ZuVxHzxUR8` (Task 6.1 Repair), `ap-Ll9bKVWs3Uc18Vm2XGJd1t` (Task 6.2 Finalization)  
**Modal App Dashboard**: [https://modal.com/apps/ronithworks/main/ap-Ll9bKVWs3Uc18Vm2XGJd1t](https://modal.com/apps/ronithworks/main/ap-Ll9bKVWs3Uc18Vm2XGJd1t)  
**Task 4 Manifest Hash Lock**: `2cc225c756555e103a5508f4ed3c9eed6d303e6a5d7d9b6851f536edf5834097`  
**Task 6 Data Manifest Hash**: `27ed7085db343ecc62e872b2ade183f460ba6da109d75cc807614df6225ca7d9`  

---

## 1. Immutable Checkpoint Inventory

| Model | Phase | Path on Modal Volume `ccpt-runs` | SHA256 Hash | Size (Bytes) | Global Step | Tokens Seen |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Model A** | Clean 1B LM | `/runs/ccpt/task6/run_1787329929/model_a/lm/checkpoints/lm_trunk_1b.pt` | `9bb8f7f2213498b6a0753eaf880c195cc7db6908d5e6c51d8f32738f27ed2135` | 431,076,941 | 30,517 | 999,981,056 |
| **Model A** | Safety (10M) | `/runs/ccpt/task6/run_1787329929/model_a/safety/checkpoints/safety_branch_10m.pt` | `f0cfbffde4edec9e50f333cc31132eb91225af3659d83394f1afea1f7a58aee4` | 431,082,923 | 1,189 | 10,004,960 |
| **Model B** | Clean 1B LM | `/runs/ccpt/task6/run_1787329929/model_b/lm/checkpoints/lm_trunk_1b.pt` | `c54110a2b95d9ee1414d14fa5c5cf0ca7731bfeca733abb2a543215f9e24a926` | 431,128,471 | 30,517 | 999,981,056 |
| **Model B** | Safety (10M) | `/runs/ccpt/task6/run_1787329929/model_b/safety/checkpoints/safety_branch_10m.pt` | `8d942343461d427e7e7a2788e183465ff28e5480b5a2b7b43f41db75753fdae4` | 431,135,915 | 1,189 | 10,004,960 |
| **Model C** | Clean 1B LM | `/runs/ccpt/task6/run_1787329929/model_c/lm/checkpoints/lm_trunk_1b.pt` | `ebad5933c0eb2b51d8cfca4515193779b858bfaa03de90a9f00bbd8180c4e1bb` | 409,074,689 | 30,517 | 999,981,056 |
| **Model C** | Safety (10M) | `/runs/ccpt/task6/run_1787329929/model_c/safety/checkpoints/safety_branch_10m.pt` | `17da544b0e790d3561b0c64d427da9617823a5f9fdb06c03ea50793422c42fdf` | 165,776,027 | 1,189 | 10,004,960 |

---

## 2. Real Production Hardware Lineage & Cost Audit

- **Production Training GPU**: **NVIDIA H100!** (80GB HBM3).
- **Benchmark Winner**: **NVIDIA H200** (selected for prospective scaling).
- **Accounting Rate**: $3.9492 / GPU-hour for H100!.

| Production Phase | Elapsed Time | Actual GPU Cost (USD) |
| :--- | :--- | :--- |
| **Model A LM Pretraining (1B tokens)** | 1,532.0 s (~25.5 min) | $1.681 |
| **Model B LM Pretraining (1B tokens)** | 1,478.0 s (~24.6 min) | $1.621 |
| **Model C LM Pretraining (1B tokens)** | 1,520.0 s (~25.3 min) | $1.667 |
| **Model A Safety Branch (10M tokens)** | 140.0 s (~2.3 min) | $0.154 |
| **Model B Safety Branch (10M tokens)** | 138.0 s (~2.3 min) | $0.151 |
| **Model C Safety Branch (10M tokens)** | 139.0 s (~2.3 min) | $0.152 |
| **Multi-GPU Benchmark Sweeps** | 180.0 s (~3.0 min) | $0.197 |
| **Task 6.1 Evaluation Run** | 45.0 s (~0.75 min) | $0.049 |
| **Task 6.2 Full Evaluation** | 65.0 s (~1.08 min) | $0.071 |
| **Total Measured GPU Cost** | — | **$5.743** |

---

## 3. FineWeb Capability Evaluation (1,024 Blocks / 1,048,576 Tokens)

| Model Configuration | Phase | Mode | Is Primary? | Cross-Entropy | Perplexity | Token Accuracy | Tokens |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Model A (Baseline)** | Clean 1B | normal | Yes | 3.3985 | **29.92** | 38.11% | 1,048,576 |
| **Model A (Baseline)** | Post-Safety | normal | Yes | 3.8496 | **46.98** (+56.9%) | 34.36% | 1,048,576 |
| **Model B (Unprotected)** | Clean 1B | controlled | Yes | 3.4321 | **30.94** | 37.85% | 1,048,576 |
| **Model B (Unprotected)** | Clean 1B | lm (bypass) | Diagnostic | 4.8585 | 128.83 | 28.56% | 1,048,576 |
| **Model B (Unprotected)** | Post-Safety | controlled | Yes | 3.7406 | **42.12** (+36.1%) | 35.11% | 1,048,576 |
| **Model B (Unprotected)** | Post-Safety | lm (bypass) | Diagnostic | 4.9551 | 141.90 | 27.95% | 1,048,576 |
| **Model C (CCPT Protected)** | Clean 1B | lm (cap-only) | Yes | 3.4180 | **30.51** | 37.85% | 1,048,576 |
| **Model C (CCPT Protected)** | Clean 1B | controlled | Yes | 3.4180 | **30.51** | 37.85% | 1,048,576 |
| **Model C (CCPT Protected)** | Post-Safety | lm (cap-only) | Yes ($\theta_C$ freeze) | 3.4180 | **30.51** (0.00%) | 37.85% | 1,048,576 |
| **Model C (CCPT Protected)** | Post-Safety | controlled | Yes (full system) | 3.4920 | **32.85** (+7.68%) | 37.05% | 1,048,576 |

---

## 4. Authoritative Full WildGuard Evaluation

### Full Risk Classification (2,344 Examples: 1,197 Harmful, 1,147 Benign)

| Model | Binary Cross-Entropy | Raw Accuracy | Harmful Accuracy | Benign Accuracy | Balanced Accuracy |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Model A (Baseline)** | 1.7106 | 47.91% | 10.19% | 87.27% | **48.73%** |
| **Model B (Unprotected)** | 3.1225 | 51.07% | 100.00% | 0.00% | **50.00%** |
| **Model C (CCPT Protected)** | 1.8306 | 54.05% | 99.92% | 6.19% | **53.05%** |

### Full Safe Generation (928 Examples / 290,384 Continuation Tokens)

| Model | Total Continuation NLL | Token-Weighted CE | Token-Weighted PPL | Controller Ablated CE ($\text{scale}=0$) | Relative Ablation Penalty |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Model A (Baseline)** | 761,196.89 | **2.6213** | **13.75** | 2.6213 | 0.00% |
| **Model B (Unprotected)** | 762,699.22 | **2.6265** | **13.83** | 3.6860 | +40.34% |
| **Model C (CCPT Protected)** | 843,544.67 | **2.9049** | **18.26** | 3.4599 | **+19.10%** |

---

## 5. Checkpoint Parameter Changes (`torch.equal`)

| Model & Group | Total Tensors | Changed Tensors | Unchanged Tensors | Total Params | Changed Params | L2 Delta |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Model A: Core LM** | 38 | 38 | 0 | 35,918,336 | 35,918,336 | 55.64 |
| **Model A: Risk Head** | 1 | 1 | 0 | 512 | 512 | 0.07 |
| **Model A: Total** | **39** | **39** | **0** | **35,918,848** | **35,918,848** | **55.64** |
| **Model B: $\theta_C$** | 38 | 38 | 0 | 33,165,824 | 33,165,824 | 43.69 |
| **Model B: $\theta_N$** | 27 | 27 | 0 | 2,754,560 | 2,754,560 | 9.34 |
| **Model B: Controllers** | 4 | 4 | 0 | 262,656 | 262,656 | 1.84 |
| **Model B: Total** | **65** | **65** | **0** | **35,920,384** | **35,920,384** | **44.68** |
| **Model C: $\theta_C$ (Capability)** | **38** | **0 (Strictly Frozen)** | **38** | **33,165,824** | **0** | **0.00** |
| **Model C: $\theta_N$ (Normative)** | **27** | **27** | **0** | **2,754,560** | **2,754,560** | **16.61** |
| **Model C: Controllers** | **4** | **4** | **0** | **262,656** | **262,656** | **4.23** |
| **Model C: Total** | **65** | **27** | **38** | **35,920,384** | **2,754,560** | **16.61** |

---

## 6. Authoritative Scale-Candidate Gate Evaluation

| Gate Criterion | Exact Formula & Threshold | Observed Value | Result |
| :--- | :--- | :--- | :--- |
| **Gate 1: Numerical Health** | No NaNs, Infs, or gradient explosions | All gradients finite; max norm $\le 26.2$ | **PASS** |
| **Gate 2: Sustained LM Learning** | Final LM Loss $< 6.0$ | Model A=3.64, Model B=3.63, Model C=3.32 | **PASS** |
| **Gate 3: Pre-Safety Parity** | $C_{\text{clean\_ctrl\_ppl}} \le 1.10 \times A_{\text{clean\_ppl}}$ (PPL $\le 32.91$) | Model C = 30.51 vs Model A = 29.92 (+1.97%) | **PASS** |
| **Gate 4: $\theta_C$ Exact Freeze** | $C_{\theta_C\text{\_changed\_tensors}} == 0$ | **0 changed tensors out of 38** | **PASS** |
| **Gate 5: Risk Balanced Accuracy** | $C_{\text{risk}} \ge \max(A, B) - 0.05$ (Threshold $\ge 45.00\%$) | Model C = **53.05%** vs Best Control B = 50.00% | **PASS** |
| **Gate 6: Safe-Generation Token CE** | $C_{\text{safe\_gen}} \le 1.10 \times \min(A, B)$ (Threshold $\le 2.8835$) | Model C = **2.9049** vs Best Control A = 2.6213 (+10.82%) | **FAIL (+10.82%)** |
| **Gate 7: Controller Ablation Effect**| Relative penalty $\ge 5.0\%$ | Model C = **+19.10%** penalty | **PASS** |
| **Gate 8: Post-Safety Parity** | $C_{\text{post\_ctrl\_ppl}} \le 1.15 \times C_{\text{clean\_ctrl\_ppl}}$ (PPL $\le 35.09$) | Model C post-safety = 32.85 (+7.68% shift) | **PASS** |

**Scale Candidate Outcome**: `SCALE_CANDIDATE = false` (7 of 8 criteria passed).

---

## 7. 10B Continuation Proof & Genuine Dry Run

- **Prefix Verification**: All 10 shards (976,544 blocks / 999,981,056 tokens) verified bit-identical.
- **Deterministic Next Batch**: Block indices 976,544 to 976,575 materialized and hashed: `12977c5a1d896662d7ef2d0dbfe7da9d75e5b91c75280de06cb020123ffcd0e2`.
- **Dry Run**: Forward pass executed on step 30,518 on Modal H100! (Loss: A=3.6467, B=5.0312, C=3.6627; LR = $2.939238 \times 10^{-4}$). Checkpoint SHA256 unchanged.
- **Continuation Flags**:
  - `MODEL_STATE_READY = true`
  - `OPTIMIZER_STATE_READY = true`
  - `SCHEDULER_READY = true`
  - `DATA_STREAM_READY = true`
  - `LOGICAL_CONTINUATION_READY = true`
  - `BITWISE_EXACT_CONTINUATION_READY = false` (missing RNG state)
  - `10B_CONTINUATION_READY = true`

---

## 8. Modal Test Execution

- **Command**: `PYTHONPATH=src pytest /root/tests -v` on Modal CPU.
- **Result**: **109 passed in 21.05s, 0 failed**.

---

## 9. Git Status & Diffs

```text
 .cursor/rules/ccpt-research.mdc               |  7 +--
 artifacts/TASK1_REVIEW_MANIFEST.md            | 29 +++-------
 docs/research/task1_ccpt_architecture_spec.md | 76 ++++++++++++++++++---------
 docs/research/task1_design_review.md          | 13 +++--
 docs/research/task1_experiment_contract.md    | 56 +++++++++++++-------
 5 files changed, 105 insertions(+), 76 deletions(-)
```

---

## 10. Deviations Noted

- WildGuard validation metrics updated to use the full frozen partitions (2,344 risk, 928 generation).
- Safe generation cross-entropy standardized to token-weighted continuation NLL.
- Cost audit derived from real parsed execution timestamps rather than manually remembered numbers.
- Continuation readiness distinguished between logical continuation and bitwise-exact continuation.
